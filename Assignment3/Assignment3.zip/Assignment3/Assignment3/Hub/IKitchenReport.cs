﻿namespace Assignment3.Hub
{
    public interface IKitchenReport
    {
        Task KitchenUpdate();
    }
}