﻿using Microsoft.AspNetCore.Identity;

namespace Assignment3.Models.Users
{
    public class KitchenUser : IdentityUser { }
}
