﻿namespace Assignment3.Models
{
    public class Expected
    {
        public int Children { get; set; }
        public DateTime Date { get; set; }
        public int Id { get; set; }
        public int Adults { get; set; }
    }
}
